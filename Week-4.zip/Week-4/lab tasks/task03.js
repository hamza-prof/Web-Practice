const numbers = [1, 2, 3, 4, 5];
 const doubled = numbers.map(function(x) {
 return x * 2;
 });
 console.log(doubled);