function reverseArray(arr){
    return arr.reverse();
    
}

const arr = [1,2,3,4,5,6,7,8,9];
reverseArray(arr);
console.log(arr);